package HyGym;

public class Battle {
	private int turn = 0;
	private Pocketmon winner;
	private Pocketmon loser;

	public void start(Pocketmon p1, Pocketmon p2) {
	}

	public void end() {
	}
}
