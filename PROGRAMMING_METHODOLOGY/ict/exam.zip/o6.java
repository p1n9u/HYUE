package prac2;
import java.util.*;

public class o6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner n = new Scanner(System.in);
		int b = n.nextInt();
		int a = b/2;
		for (int i = 1;i<a+1;i++) {
			for (int j = 1;j<i+1;j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		if(b%2==1) {
			for (int i = a+1;i>0;i--) {
				for (int j = i;j>0;j--) {
					System.out.print("*");
				}
				System.out.println();
			}
		}
		else {
			for (int i = a;i>0;i--) {
				for (int j = i;j>0;j--) {
					System.out.print("*");
				}
				System.out.println();
			}
		}

	}

}
