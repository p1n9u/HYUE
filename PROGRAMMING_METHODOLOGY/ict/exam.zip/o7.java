package prac2;
import java.util.*;

public class o7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner n = new Scanner(System.in);
		int a = n.nextInt();
		for (int i = 0;i<a+1;i++) {
			for(int j=0;j<i+1;j++) {
				System.out.print(pascal(i,j)+" ");
			}
			System.out.println();
		}

	}
	public static int pascal(int n,int r) {
		if (r==0) {
			return 1;
		}
		else {
			if(n==r) {
				return 1;
			}
			else {
				int c=1;
				int b=1;
				int a=1;
				for (int i =1;i<n+1;i++) {
					c*=i;
				}
				for (int i =1;i<r+1;i++) {
					b*=i;
				}
				for (int i =1;i<n-r+1;i++) {
					a*=i;
				}
				return c/(b*a);
			}
		}
		
	}

}
