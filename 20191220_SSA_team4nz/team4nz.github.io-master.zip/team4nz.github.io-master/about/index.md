---
layout: post
title: About
---
<p>
HYUE ICT Media Tech - 2019 Smart Sensor & Actuator ( MMT2006 , Pf. YWC )
<br>
Team project using EV3 LEGO MindStorms.
<br>
The site is for Portfolio <a href="https://team4nz.github.io/">: team manz </a>.
</p>

<hr>

<p>
Team Name : MANZ
<br>
Team Number : 1
<br>
Team Members : 김도원 김민준 나윤재 정대윤 정만성
</p>

<p>
Record the process of creating a guide robot prototype for the blind.
<br>
: Intro, Task-Try&Catch, Dev-Log, Demo-Trial, PPT.
</p>