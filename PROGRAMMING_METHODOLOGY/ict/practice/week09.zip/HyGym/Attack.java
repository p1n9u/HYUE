package HyGym;

interface Attack {

	boolean attack(Pocketmon target);

}
