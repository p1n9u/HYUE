package prac2;
import java.util.*;
public class o2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int b = 0;
		Scanner n = new Scanner(System.in);
		System.out.println("input");
		int c = n.nextInt();
		for (int i = 1; i<c;i++) {
			b=0;
			for(int j=1;j<i;j++) {
				if(i%j==0) {
					b+=j;
				}
			}
			if(b==i) {
				System.out.println(i);
			}
		}

	}

}
