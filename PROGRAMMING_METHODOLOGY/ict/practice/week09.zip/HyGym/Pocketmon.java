package HyGym;

public abstract class Pocketmon implements Attack, Interaction {

	private String name;
	private double hp;
	private int str;

	public Pocketmon(String name, double hp, int str) {

	}



}
