package HyGym;

public interface Interaction {
	void happy();
	void sad();
}
