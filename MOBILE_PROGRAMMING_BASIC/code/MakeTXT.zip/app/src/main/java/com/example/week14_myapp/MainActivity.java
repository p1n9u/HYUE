package com.example.week14_myapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText txt_name, txt_text;
    TXTfile TXTfile = new TXTfile(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt_name = (EditText)findViewById(R.id.txt_name);
        txt_text = (EditText)findViewById(R.id.txt_text);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.save_txt:
                String msName = txt_name.getText().toString();
                String msData = txt_text.getText().toString();
                TXTfile.save(msData, msName);
                txt_name.setText("");
                txt_text.setText("");
                Toast.makeText(this, msName + " : 저장", Toast.LENGTH_LONG).show();
                return true;
            case R.id.load_txt:
                String moName = txt_name.getText().toString();
                String moData = TXTfile.load(moName);
                txt_text.setText(moData);
                Toast.makeText(this, moName + " : 불러오기", Toast.LENGTH_LONG).show();
                return true;
            case R.id.delete_txt:
                String mdName = txt_name.getText().toString();
                TXTfile.delete(mdName);
                txt_name.setText("");
                txt_text.setText("");
                Toast.makeText(this, mdName + " : 삭제", Toast.LENGTH_LONG).show();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
