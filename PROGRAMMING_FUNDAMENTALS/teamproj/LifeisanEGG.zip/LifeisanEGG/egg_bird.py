# paddle = 파란공 (움직이는 새가 될 예정)
# Ball = 라벨 (띄우는 텍스트가 될 예정)


from egg_reader import *
import tkinter as tk

class Game(tk.Frame):
    def __init__(self, master):
        super(Game, self).__init__(master)
        self.width = 610
        self.height= 400
        self.canvas = tk.Canvas(self, bg = '#aaaaaa', width = self.width, height = self.height)
        self.canvas.pack()
        self.pack()
        self.paddle = Paddle(self.canvas, self.width/2, 326)

        self.items = {}
        
        self.ball = Ball(self.canvas, self.width/2, 100, 1)
        self.items[self.ball.item] = self.ball

        self.game_loop()
        self.canvas.focus_set()
        self.canvas.bind('<Left>',
                         lambda _: self.paddle.move(-10, 0))
        self.canvas.bind('<Right>',
                         lambda _: self.paddle.move(10, 0))
        self.canvas.bind('<Up>',
                         lambda _: self.paddle.move(0, -10))
        self.canvas.bind('<Down>',
                         lambda _: self.paddle.move(0, 10))
#        self.canvas.bind('<space>',
#                         lambda _: self.paddle.move(0, -100)) 점프기능
        txt=open("test.txt","r")
        ltxt=txt.read()
        txt.close()
        ltxt2=ltxt[0]
        self.text = self.draw_text(300, 200,
                                  ltxt2)

    def draw_text(self, x, y, text, size='40'):
        font = ('Helvetica', size)
        return self.canvas.create_text(x, y, text=text,
                                       font=font)

        
    def game_loop(self):
        self.check_collisions()
        self.paddle.update()
        self.after(50, self.game_loop)

    def check_collisions(self):
        paddle_coords = self.paddle.get_position()
        items = self.canvas.find_overlapping(*paddle_coords)
        objects = [self.items[x] for x in items if x in self.items]
        self.paddle.collide(objects)


class GameObject:
    def __init__(self, canvas, item):
        self.canvas = canvas
        self.item = item

    def get_position(self):
        return self.canvas.coords(self.item)

    def move(self, x, y):
        self.canvas.move(self.item, x, y)

    def delete(self):
        self.canvas.delete(self.item)


class Paddle(GameObject):
    def __init__(self, canvas, x, y):
        self.radius = 10
        self.direction = [0, 0]
        item = canvas.create_oval(x - self.radius, y - self.radius,
                                  x + self.radius, y + self.radius,
                                  fill = 'blue')
                                  
        super(Paddle, self).__init__(canvas, item)



    def collide(self, game_objects):

        for game_object in game_objects:
            if isinstance(game_object, Ball):
                game_object.hit()



    def update(self):
        coords = self.get_position()
        width = self.canvas.winfo_width()

        x = self.direction[0]
        y = self.direction[1]
        self.move(x, y)


class Ball(GameObject):
    def __init__(self, canvas, x, y, hits):
        self.radius = 10
        self.hits = hits
        item = canvas.create_oval(x-self.radius, y-self.radius,
                                  x+self.radius, y+self.radius,
                                  fill='white', tags ='Ball')
        super(Ball, self).__init__(canvas, item)

    def hit(self):
        self.hits -= 1
        if self.hits == 0:
            self.delete()


if __name__ == '__main__':
    root = tk.Tk()
    root.title('Game Title')
    game = Game(root)
    game.mainloop()
    game.text_label()
