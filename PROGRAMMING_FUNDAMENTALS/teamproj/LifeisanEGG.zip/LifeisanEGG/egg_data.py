from tkinter import *
from egg_reader import *

######## Data side ########## 
class Input:

    def __init__(self, master):
        #value
        self.id = Reader.read_data("last", "id_")
        self.list, self.listnum = [' ', '취미', '건강', '학업'], 0 
        self.catecolor = ["#c0c0c0", "#e5d1b7", "#d3dbbc", "#bcced6"]
        self.category = self.list[self.listnum]
        self.tagon = False
        self.tags = [] ###
        self.datetime = self.turn_datetime()
        self.score = 0
        
        #layout
        self.inframe = Frame(master, width = 250, height = 150)
        self.area = Text(self.inframe, width = "23", height="9",\
                         font=("NanumGothic", 10), padx=10, pady=5, relief="flat") #
        self.scale = Scale(self.inframe, from_=100, to=-100,\
                                 border=0, bg="#FFFFFF",width="5")
        self.catelabel = Button(self.inframe, text=str(self.category), command = lambda : self.swipe_category(3,0,1),
                               width="4", height="2", fg="#FFFFFF", bg=self.catecolor[self.listnum], relief=FLAT, overrelief =FLAT)
        
    def swipe_category(self, first, last, delta):
        if self.listnum==first:
            self.listnum=last
        else:
            self.listnum=self.listnum+delta
        self.category=self.list[self.listnum]
        self.catelabel.config(text = str(self.category), bg=self.catecolor[self.listnum])

    def turn_datetime(self):
        import datetime as d
        today = d.datetime.today()
        self.datetime = today.strftime('%Y-%m-%d_%H:%M:%S')
        return self.datetime
    

class Output:

    def __init__(self, master):
        self.master = master
        self.bgcolor = "#ccc1bb"
        self.canvas = Canvas(master, width=250,height=350, bg=self.bgcolor)
        self.canvas.outframe = Frame(self.canvas, width=250, bg=self.bgcolor)
        self.canvas.create_window(0, 0, anchor=N+E, window=self.canvas.outframe)
        self.scroll = Scrollbar(master, orient="vertical", command=self.canvas.yview)        

    def scroll_update(self):
        self.canvas.configure(scrollregion=self.output.canvas.bbox(ALL))
        
    def update(self, color):
        self.bgcolor=color
        self.canvas = Canvas(self.master, width=250,height=350, bg=self.bgcolor) #사실 스크롤 어떤 알고리즘인지 이해못함ㅋ
        
#############################
