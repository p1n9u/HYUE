####### Reader side ######### B1
import os


class Reader:

    @staticmethod
    def write_data(id_, contents, score, category, tag, datetime):
        filtered = ""
        for i in contents:
            if i not in " | \n ":
                filtered += i
        data = str(id_)+'|'+str(filtered)+'|'+ str(score)+'|'+ str(category)+'|'+ str(tag)+'|'+str(datetime)
        t4 = open("temp_data.txt", "a")
        t4.write(str(data))
        t4.write('\n')
        t4.close
        

    @staticmethod
    def read_data(i, what):
        t = open("temp_data.txt", "r")
        s={}
        for line in t.readlines():
            id_, contents, score, category, tag, datetime = line.strip('\n').split('|')
            s[int(id_)] = (contents, score, category, tag, datetime)
            t.close

        if i=='last' and what == 'id_':
            return id_
            
        king = s[i]
        if what == 'contents' :
            return king[0]
        elif what == 'score' :
            return king[1]
        elif what == 'category' :
            return king[2]
        elif what == 'tag' :
            return king[3]
        elif what == 'datetime' :
            return king[4]
        
        
    @staticmethod
    def score_data(category):
        study=[]
        hobby=[]
        health=[]
        for i in range(3):
            if Reader.read_data(i,"category")=="학업":
                study.append(i)
            elif Reader.read_data(i,"category")=="취미":
                hobby.append(i)
            elif Reader.read_data(i,"category")=="건강":
                health.append(i)

        if category == '학업' :
            sum = 0
            count = 0
            for x in study:
                count += 1
                sum = int(Reader.read_data(x,"score"))
            avr_score = sum / count

        if category == '취미' :
            sum = 0
            count = 0
            for x in hobby:
                count += 1
                sum = int(Reader.read_data(x,"score"))
            avr_score = sum / count

        if category == '건강' :
            sum = 0
            count = 0
            for x in health:
                count += 1
                sum = int(Reader.read_data(x,"score"))
            avr_score = sum / count
        return avr_score

    @staticmethod
    def write_wing(offang, offlen, feathers):
        filtered = ""
        for i in contents:
            if i != "|":
                filtered += i
        data = str(offang)+'|'+str(offlen)+'|'+ str(feathers)
        t4 = open("temp_wing.txt", "a")
        t4.write(data)
        t4.write('\n')
        t4.close

    @staticmethod
    def read_wing():
        t = open("temp_wing.txt", "r")
        for line in t.readlines():
            offang, offlen, feathers = line.strip('\n').split('|')
            t.close
        feathers_dict = feathers # dict의 str 타입인 feathers를 dict로 바꾸는 방법?
        return int(offang), int(offlen), feathers_dict

    @staticmethod
    def hatch():
        f = Reader.read_data(1,'datetime')
        file_name = f[:10] + '~_data' + '.txt'
        try:
            import os
            os.rename('temp_data.txt',file_name)
        except FileExistsError:
            file_name = file_name = Reader.read_data(1,'datetime') + "_data" + ".txt"
        t = open('temp_data.txt','w')
        t.write('0|||||')
        t.write('\n')
        t.close
            


        file_name = file_name[:10]+'~_wing'+'.txt'
        try:
            with open("temp_wing.txt", "rb") as file:
                with open(file_name, "wb") as f:
                    f.write(file.read())
        except UnicodeDecodeError:
            with open("temp_wing.txt", "r") as f:
                with open(file_name, "wb") as f:
                    f.write(file.read())

        try:
            with open("temp_wing.txt", "wb") as f:
                f.close()
        except UnicodeDecodeError:
            with open("temp_wing.txt", "w") as f:
                f.close()
        
    
####################################
