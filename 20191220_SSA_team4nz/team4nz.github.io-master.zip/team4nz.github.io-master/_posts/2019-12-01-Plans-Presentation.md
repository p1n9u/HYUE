---
layout: post
categories: posts
title: 4. Plans and Presentation
tags: [ppt]
date-string: DECEMBER 01, 2019
---

# Plans

> Development direction

  * 모션센서와 적외선센서를 통해 UI를 개선
  * 테이프의 단점을 보안할 수 있는 방안을 강구
  * Real World의 Exception Handling 처리 개선
  * 중간의 경로를 수정하거나, 동시의 여러 개를 운용할 수 있도록 교통 시스템 연구


# Presentation

> Semi PPT [ November 08, 2019 ]
<center>
<iframe width="560" height="315" src="https://www.youtube.com/embed/xdARs_22igM" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</center>

> Final PPT [ DECEMBER 06, 2019 ]
<center>
<iframe width="560" height="315" src="https://www.youtube.com/embed/DpnBUZdeUj4" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</center>

> Final PPT DEMO [ DECEMBER 06, 2019 ]
<center>
<iframe width="560" height="315" src="https://www.youtube.com/embed/betwKUKrKhM" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</center>