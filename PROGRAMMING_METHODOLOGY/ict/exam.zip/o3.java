package prac2;
import java.util.*;

public class o3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner n = new Scanner(System.in);
		System.out.println("input");
		int a = n.nextInt();
		int b = n.nextInt();
		int c=0;
		int e;
		int f;
		if (a>b) {
			e=b;
			f=a;
		}
		else {
			e=a;
			f=b;
		}
		for(int i=1;i<e;i++) {
			if((a%i==0)&&(b%i==0)) {
				c=i;
				
			}
		}
		System.out.println(c);
		int i=1;
		int g;
		while(true) {
			g= c * i;
			if((g%a==0)&&(g%b==0)) {
				break;
			}
			i++;
		}
		System.out.println(c+" "+g);
	}

}
