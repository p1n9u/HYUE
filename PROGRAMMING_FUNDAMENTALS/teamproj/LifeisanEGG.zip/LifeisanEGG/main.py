#으아아ㅇ아ㅏ아아아ㅏㅇ
from tkinter import *
from egg_wing import *
from egg_bird import *
from egg_data import *
from egg_reader import *
import time
import random
import colorsys
import pickle
import codecs



######################################
class App(Frame):

    def __init__(self, master):
        super().__init__(master, width=700, height=500)
        #init
        self.master = master
        self.left = Graphic_frame(self.master)
        self.right = Data_frame(self.master)

        #load wing, data
        self.right.load_data()

        #data-wing response
        self.right.input.area.bind("<Key>", lambda e:\
                                   self.fluttering(e, self.right.input.scale.get(),
                                                         len(self.right.input.area.get('0.0',END)))
                                 )
        self.right.input.area.bind("<KeyRelease-Return>"or"<KeyRelease-KP_Enter>", lambda e:\
                                   self.displaying(self.right.input.scale.get()))
        #cloud response
        self.left.canvas.tag_bind("egg", "<Button-1>",lambda e: self.left.save_wing())
        self.left.canvas.tag_bind("egg", "<Double-Button-1>", lambda e: self.hatch())
        self.left.canvas.tag_bind("cloud", "<Button-1>", lambda e: self.left.colouring(e))
        self.left.canvas.tag_bind("feather", "<Button-1>", lambda e: self.left.coloured(e))
        
    def fluttering(self, e, score, leng):
        """typing - fluttering!"""
        if e.keysym == "BackSpace":
            score = -score
        self.left.wing.flutter(score, leng)
        self.update_wing()
        
    def displaying(self, score):
        """return - wing! data! baaam!!"""
        #wing
        if self.right.input.category == '건강':
            self.left.wing.grow(int(score))
            self.update_wing()
        elif self.right.input.category == '학업':
            self.left.wing.fledge(int(score))
            self.update_wing()
        elif self.right.input.category == '취미':
            self.left.wing.float(int(score), len(self.right.input.area.get('0.0',END)))
            self.left.set_cloud()
        #data
        self.right.input.score = int(score)
        self.right.send_data()
            
    def update_wing(self):
        self.left.set_wing(self.left.wing.upperarm,
                           self.left.wing.forearm,
                           self.left.wing.hand)
    def hatch(self):
        print("깨어났습니다!")
        Reader.hatch()
        self.master.destroy()
 
        
############# frame side ############ 2F
        
class Graphic_frame:

    def __init__(self, master):
        self.frame = Frame(master, width=500, height=500)
        # init
        self.canvas = Canvas(master, width=500, height=500, bg="#c7d7d7")
        self.egg = Egg(self.canvas)
        try:
            with open("temp_wing.txt", "rb") as f:
                self.wing = Wing(self.canvas, self.egg, self.load_wing())
        except UnicodeDecodeError:
            self.wing = Wing(self.canvas, self.egg, self.start_wing())
        except EOFError:
            self.wing = Wing(self.canvas, self.egg, self.start_wing())
        

        # array
        self.canvas.grid(row=0, column=0, sticky=W) #

        # display
        self.set_egg(self.egg.shape)
        self.set_wing(self.wing.upperarm, self.wing.forearm, self.wing.hand)

    ### setting canvas
    def set_egg(self, shape): ############################################################## size, status, name ... etc 알에 관한 건 나중에. 일단은 기본 옵셋으로 생각..
        self.canvas.create_oval(shape, fill="#ffffff", outline="", tags="egg")

    def set_wing(self, b1, b2, b3):
        self.canvas.delete("bone")
        self.canvas.create_line(b1.line, tags="bone", fill='DarkGray', width=3)
        self.canvas.create_line(b2.line, tags="bone", fill='Gray', width=3)
        self.canvas.create_line(b3.line, tags="bone", fill='DimGray', width=3)
        
        self.canvas.delete("feather")
        for i in range(3):
            for f in self.wing.feather[i]["hand"]:
                self.set_feather(f, b3, i)
            for f in self.wing.feather[i]["fore"]:
                self.set_feather(f, b2, i)
            for f in self.wing.feather[i]["uppr"]:
                self.set_feather(f, b1, i)
                
        self.canvas.delete("drop")
                
    def set_feather(self, f, bone, i):
        f.bonepart = bone
        f.wingang = self.wing.offang
        f.update()
        self.canvas.create_polygon(f.hair, fill=f.color, outline=f.line, tags=("feather", 'f'+str(i)+str(bone)+str(len(self.wing.feather[i][str(bone)]))))
        self.canvas.create_polygon(f.stick, fill="#e0dbd9", outline="", tags=("feather", 'f'+str(i)+str(bone)+str(len(self.wing.feather[i][str(bone)]))))

    def set_cloud(self):
        self.canvas.delete("cloud")
        clouds = self.wing.cloud
        for i in range(len(clouds)):
            self.canvas.create_oval(clouds[i].shape1, fill=clouds[i].color, outline="", tags=("c"+str(i),"cloud"))
            self.canvas.create_rectangle(clouds[i].shape2, fill=clouds[i].color, outline="", tags=("c"+str(i),"cloud"))
            self.canvas.create_oval(clouds[i].shape3, fill=clouds[i].color, outline="", tags=("c"+str(i),"cloud"))

    def colouring(self, event):
        item = self.canvas.find_closest(event.x, event.y)[0]
        tags = self.canvas.gettags(item)
        cloud = self.wing.cloud[int(tags[0][1:])]
        colour = Pour()
        for i in range(cloud.drops):
            colour.ing(self.canvas,
                            random.randint(int(cloud.shape1[0]), int(cloud.shape3[2])),
                            random.randint(int(cloud.y0+cloud.h/2), int(cloud.y0+cloud.h/2+100)),
                            1, 10, cloud.color) #random.choice(colors)
        self.selected = cloud
    
    def coloured(self, event):
        self.canvas.delete("drop")
        cloud = self.selected
        item = self.canvas.find_closest(event.x, event.y)
        name = self.canvas.gettags(item)[1][1:]
        feather = self.wing.feather[int(name[0])][name[1:5]][int(name[5:])-1]
        colour = Pour()
        for i in range(cloud.drops):
            drops = colour.ing(self.canvas,
                            random.randint(int(feather.x), int(feather.x+feather.w)),
                            random.randint(int(feather.y), int(feather.y+feather.h)),
                            1, 10, cloud.color)
        feather.color = cloud.color

            
    ### wing data
    def save_wing(self):
        print("저장되었습니다")
        self.set_wing(self.wing.upperarm,
                           self.wing.forearm,
                           self.wing.hand)
        wing_data = [self.wing.offang, self.wing.offlen, self.wing.feather]
        with open("temp_wing.txt", "wb") as f:
            pickle.dump(wing_data, f)
    def start_wing(self): 
        return 80, 30, {0:{"uppr":[], "fore":[], "hand":[]}, #bot
                        1:{"uppr":[], "fore":[], "hand":[]}, #mid
                        2:{"uppr":[], "fore":[], "hand":[]}} #top
    def load_wing(self):
        with open("temp_wing.txt", "rb") as f:
            data = pickle.load(f)
            return data[0], data[1], data[2]

        
    
class Data_frame:

    def __init__(self, master):
        #init
        self.frame = Frame(master, width=200, height=500) ## w h
        self.output = Output(self.frame)
        self.input = Input(self.frame)
        
        #array
        self.frame.grid(row=0, column=1, sticky=E)
        
        self.input.inframe.grid(row=1, column=0)
        self.input.area.pack(side=LEFT)
        self.input.scale.pack(side=TOP)
        self.input.catelabel.pack(side=TOP, padx=2, pady=4)

        self.output.canvas.grid(row=0, column=0, sticky=E)
        self.output.canvas.configure(yscrollcommand=self.output.scroll.set)
        self.output.scroll.config(command=self.output.canvas.yview)
        self.output.canvas.configure(scrollregion = self.output.canvas.bbox("all"))

        #event bind
        self.input.area.bind("<Control-Left>", lambda e: self.input.swipe_category(3,0,1))
        self.input.area.bind("<Control-Right>", lambda e: self.input.swipe_category(0,3,-1))
        self.output.canvas.bind_all("<MouseWheel>", lambda x: self.output.canvas.yview_scroll(int(-1*(x.delta/40)), "units"))

    def load_data(self):
        f = open("temp_data.txt", "r")
        n = f.readlines()
        f.close
        if len(n)<=300:
            startline = 0            
        else:
            startline = len(n)-300
            
        for i in range(startline, len(n)):
            temp = Label(self.output.canvas.outframe, text=Reader.read_data(i,"contents"),
                  name = str(i), bg="#FFFFFF", wraplength=230, padx=2, pady=4)
            temp.grid(row = i, column = 0, padx = 10, pady = 6, sticky=NE)

            self.output.canvas.configure(scrollregion=self.output.canvas.bbox(ALL))
            self.output.canvas.yview_moveto(1)
                
    def send_data(self):
        if self.input.area.get("1.0","end-2c")!="":
            if "error" in locals():
                error.destroy()
            #make label
            temp = Label(self.output.canvas.outframe, text=self.input.area.get("1.0","end-2c"),\
                         name = self.input.id, bg="#FFFFFF", wraplength=230, padx=2, pady=4)
            temp.grid(row = int(self.input.id), column = 0, padx = 10, pady = 6, sticky=NE)
            #imsybangpyeon
            error = Label(self.output.canvas.outframe, text=" ", bg="#ccc1bb", wraplength=1)
            error.grid(row = int(self.input.id)+1, column = 0, padx = 10, pady = 6, sticky=NE)
            #update id
            self.input.id = str(int(self.input.id) + 1)
            self.input.area.delete(1.0, END)
            #write data
            Reader.write_data(self.input.id, temp["text"], self.input.score,\
                              self.input.category, self.input.tags, self.input.datetime)
            #output scroll update
            self.output.canvas.configure(scrollregion=self.output.canvas.bbox(ALL))
        self.output.canvas.yview_moveto(1)



#############################


window = Tk()
window.title("Life is an egg, wide awake")
App(window)
window.mainloop()
