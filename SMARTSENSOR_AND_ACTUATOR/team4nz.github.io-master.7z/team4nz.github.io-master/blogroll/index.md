---
layout: post
title: Blogroll
---
A lot of the inspiration for this blog comes from the following:

Cincinnati:
<ol>
<a target="_blank" href="http://5chw4r7z.blogspot.com">5chw4r7z</a><br>
<a target="_blank" href="http://cincyopolis.wordpress.com/">cincyopolis</a><br>
<a target="_blank" href="http://www.diggingcincinnati.com/">diggingcincinnati</a><br>
<a target="_blank" href="http://handeaux.tumblr.com/">handeaux</a><br>
<a target="_blank" href="http://www.hoperatives.com/">hoperatives</a><br>
<a target="_blank" href="http://queencitydiscovery.blogspot.com/">queencitydiscovery</a><br>
<a target="_blank" href="http://www.urbancincy.com/">urbancincy</a><br>
</ol>

Data Science/Open Data/Mapping/Machine Learning/Civic Data Hacking:
<ol>
<a target="_blank" href="http://fivethirtyeight.com/">FiveThirtyEight</a><br>
<a target="_blank" href="http://www.floatingsheep.org/">FloatingSheep</a><br>
<a target="_blank" href="http://geoffboeing.com/">Goeff Boeing</a><br>
<a target="_blank" href="http://iquantny.tumblr.com/">IQuantNY</a><br>
<a target="_blank" href="http://priceonomics.com/">Pricenomics</a><br>
</ol>

Urbanism/Urban Design:
<ol>
<a target="_blank" href="http://www.andrewalexanderprice.com/blog.php">Andrew Alexander Price</a><br>
<a target="_blank" href="http://www.citylab.com/">CityLab</a><br>
<a target="_blank" href="http://detroiturbanism.blogspot.com/">Detroit Urbanism</a><br>
<a target="_blank" href="http://granolashotgun.com/">GranolaShotgun</a><br>
<a target="_blank" href="http://www.gcbl.org/blog">GCBL</a><br>
<a target="_blank" href="http://oldurbanist.blogspot.com/">Old Urbanist</a><br>
<a target="_blank" href="http://ohio.streetsblog.org/">StreetsBlog - Ohio</a><br>
<a target="_blank" href="http://rebelmetropolis.org/">Rebel Metropolis</a><br>
<a target="_blank" href="http://www.strongtowns.org/journal/">Strong Towns</a><br>
<a target="_blank" href="http://urbankchoze.blogspot.com/">Urban Kchoze</a><br>
</ol>

Travel/Art/Biking/Misc:
<ol>
<a target="_blank" href="http://jakubsan.tumblr.com/">Jakub Rozalski </a><br>
<a target="_blank" href="http://nutmegcountry.tumblr.com/">Nutmeg Country</a><br>
<a target="_blank" href="http://simonstalenhag.tumblr.com/">Simon Stålenhag</a><br>
</ol>