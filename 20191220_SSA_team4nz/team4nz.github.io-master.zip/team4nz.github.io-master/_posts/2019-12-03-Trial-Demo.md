---
layout: post
categories: posts
title: 2. Trial Demo
tags: [trial, demo, video]
date-string: DECEMBER 03, 2019
---
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="_/js/libs/jquery-1.9.1.min.js"><\/script>')</script>

# Testing - Map1 : restroom
<center>
    <img src="/images/map/manz-map1.jpg">
</center>

### idx3

> Trial 1

<center>
<iframe width="560" height="315" src="https://www.youtube.com/embed/f7dLuNlptLs" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</center>

> Trial 2
<center>
<iframe width="560" height="315" src="https://www.youtube.com/embed/rvUHuTyKeZw" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</center>


# Testing - Map2 : office room
<center>
    <img src="/images/map/manz-map2.jpg">
</center>

### idx6

> Trial 1
<center>
<iframe width="560" height="315" src="https://www.youtube.com/embed/q6tEOeBuu_g" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</center>

> Trial 2
<center>
<iframe width="560" height="315" src="https://www.youtube.com/embed/LR3myTeNBnA" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</center>


#### Next

> link : <a target="_blank" href="https://team4nz.github.io//posts/2019-12-02/Development-Log.html"> 03. Development Log