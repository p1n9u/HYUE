package prac2;

import java.util.*;

public class o4 {
	public static void main(String[] args) {
		Scanner n = new Scanner(System.in);
		int[] a = new int[10];
		for(int i = 0 ;i<10;i++) {
			a[i] = n.nextInt();
		}
		int b = n.nextInt();
		for (int i = 9;i>9-b;i--) {
			System.out.println(a[i]);
		}
		
	}
}
