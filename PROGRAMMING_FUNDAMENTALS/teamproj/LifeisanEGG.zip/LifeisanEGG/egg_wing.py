from tkinter import *
import math
import random
import colorsys

####### Graphic side ########
class Egg:
    
    def __init__(self, master):
        self.w = 120 #
        self.h = self.w*1.25 #
        self.x0, self.y0 = 70, 200 #
        self.x, self.y = self.x0 + self.w, self.y0 + self.h #
        self.shape = [self.x0, self.y0, self.x, self.y]


class Wing:

    def __init__(self, master, egg, data):
        self.egg, self.cloud = egg, []
        self.offang, self.offlen, self.feather = data[0], data[1], data[2]
        self.bone_update()

    def bone_update(self):
        self.shoulder_x, self.shoulder_y = self.egg.x0 + self.egg.w/10*(6.5), self.egg.y0 + self.egg.h/10*(2) ##### 비율 고정?
        self.upperarm = Bone(self.shoulder_x, self.shoulder_y, self.offang, self.offlen, "uppr")
        self.forearm = Bone(self.upperarm.x, self.upperarm.y, -self.offang, self.offlen*1.5, "fore")
        self.hand = Bone(self.forearm.x, self.forearm.y, self.offang-10, self.offlen*0.7, "hand")
        self.bone = [self.upperarm, self.forearm, self.hand]

    ######

    def flutter(self, scale, score): #
        score = score*0.01 #
        if scale>0 and self.offang>-50:
            self.offang -= score
            self.bone_update()
        elif scale<0 and self.offang<80:
            self.offang += score
            self.bone_update()
    
    def grow(self, score):
        """control length"""
        self.offlen += score*0.01
        self.bone_update()

    def fledge(self, score):
        """init each feather"""
        def flopsy(row, n, col, mode, size, w, prev_h, next_h):
            if mode=="->":
                 h = prev_h + size*len(row[str(col)])
                 row[str(col)].append(Feather(w, h, n, len(row[str(col)]), self.offang, mode, col, self.feather))
            elif mode=="<-":
                 h = next_h + size*len(row[str(col)])
                 row[str(col)].append(Feather(w, h, n, len(row[str(col)]), self.offang, mode, col, self.feather))
        def fluffy(row, w, n, col, mode, size):
            if 0 <= len(row[str(col[0])])*(col[0].wid)/n[0] <= col[0].wid:
                flopsy(row, n[0], col[0], mode, size[0], w, w*9/2, w*9/2)
            elif 0 <= len(row[str(col[1])])*(col[1].wid/n[1]) <= col[1].wid:
                flopsy(row, n[1], col[1], mode, size[1], w, w*9/2, w*9/2 + size[0]*len(row[str(col[0])]))
            elif 0 <= len(row[str(col[2])])*(col[2].wid/n[2]) <= col[2].wid:
                flopsy(row, n[2], col[2], mode, size[2], w, w*9/2 + size[1]*len(row[str(col[1])]),
                       w*9/2 + size[0]*len(row[str(col[0])]) + size[1]*len(row[str(col[1])]))
        if score>0:
            w = self.offlen*0.25 #
            if 60<score<=100:
                row, n, size = self.feather[0], [5, 4, 2], [-3, 5, -3] #
                col = [self.hand, self.forearm, self.upperarm]
                fluffy(row, w*3, n, col, "<-", size)
            if 30<score<=60:
                row, n, size = self.feather[1], [5, 4, 7], [5, 0.5, 0.5] #
                col = [self.hand, self.forearm, self.upperarm]
                fluffy(row, w*1, n, col, "<-", size)
            if 0<score<=30:
                row, n, size = self.feather[2], [5, 6, 8], [0, -3, -3] #
                col = [self.upperarm, self.forearm, self.hand]
                fluffy(row, w*1, n, col, "->", size)
        if score<0:
            randlist = ["uppr", "fore", "hand"]
            randname = randlist[random.randint(0,2)]
            randrow = random.randint(0,2)
            try:
                del self.feather[randrow][randname][random.randint(0,len(self.feather[randrow][randname])-1)]
            except IndexError:
                pass
            except ValueError:
                pass
            
                
    def float(self, score, leng):
        """init color pan _ cloud!"""
        self.cloud.append(Cloud(score, leng))

    def colouring(self, selected, target):
        target.color = selected.color


class Bone:

    def __init__(self, x0, y0, angle, length, name):
        self.name = name
        self.x0, self.y0 = x0, y0
        self.ang = angle
        self.len = length
        self.update()
        self.wid = self.x - self.x0

    def __str__(self):
        return str(self.name)

    def update(self):
        self.x, self.y = self.linear()
        self.line = [self.x0, self.y0, self.x, self.y]
        return self.line

    def linear(self):
        return self.x0 + math.cos(math.radians(self.ang)) * self.len, \
               self.y0 + math.sin(math.radians(self.ang)) * self.len

    
class Feather:

    def __init__(self, w, h, n, index, wingang, mode, bonepart, featherlist):
        #set attribute
        self.w, self.h = w, h
        self.maxnum, self.index, self.wingang,  = n, index, wingang
        self.color, self.line = "#B7AEA7", "#afa7a1"
        self.mode, self.bonepart, self.feathers = mode, bonepart, featherlist
        self.update()

    def update(self):
        #define position
        self.x, self.y = self.control_pos()
        self.hair = [[self.x+0, self.y+self.h/90*10], [self.x+self.w/20*(-3), self.y+self.h/90*20],
                [self.x+self.w/20*(-5), self.y+self.h/90*70], [self.x+self.w/20*(-2), self.y+self.h/90*80],
                [self.x+self.w/20*10, self.y+self.h/90*90], [self.x+self.w/20*22, self.y+self.h/90*80],
                [self.x+self.w/20*10, self.y+self.h/90*17], [self.x+self.w/20*4, self.y+self.h/90*10]]
        self.stick = [[self.x+self.w/20*0, self.y+self.h/90*0], [self.x+self.w/20*4, self.y+self.h/90*2], [self.x+self.w/20*10, self.y+self.h/90*70]]
        #adjust angle
        if 35<=self.wingang:
            i,w = self.index*1/(self.wingang-34), 35
        else:
            i,w = self.index,self.wingang
        if str(self.bonepart) == "hand" and self.mode=="<-":
            ang = 45-i*10-w
            self.control_ang(ang)
        elif str(self.bonepart) == "fore" and self.mode=="<-":
            ang = 10-i*4-w*0.4
            self.control_ang(ang)
        elif str(self.bonepart) == "hand" and self.mode=="->":
            ang = 10-i*0.9-w*0.7
            self.control_ang(ang)
            
    ######
    def control_pos(self):
        self.gap = (self.bonepart.x-self.bonepart.x0)/self.maxnum
        self.dx = self.index*self.gap
        
        if self.mode == "->":
            x0,y0,x1,y1 = self.bonepart.x0, self.bonepart.y0, self.bonepart.x, self.bonepart.y
        elif self.mode == "<-":
            self.dx = -self.dx
            x0,y0,x1,y1 = self.bonepart.x, self.bonepart.y, self.bonepart.x0, self.bonepart.y0
        
        a = (y1-y0)/(x1-x0)
        k = y0 - a*x0 
        y = a*(x0 + self.dx) + k

        self.x, self.y = x0 + self.dx, y
        return self.x, self.y

    def control_ang(self, ang):
        def rotate(x, y, ang):
            _x = (x-self.x) * math.cos(ang) + (y-self.y) * math.sin(ang)
            _y = -(x-self.x) * math.sin(ang) + (y-self.y) * math.cos(ang)
            return _x + self.x, _y + self.y
    
        for xy in self.hair:
            xy[0],xy[1] = rotate(xy[0], xy[1], math.radians(ang))
        for xy in self.stick:
            xy[0],xy[1] = rotate(xy[0], xy[1], math.radians(ang))


class Cloud:

    def __init__(self, score, leng):
        # position, shape
        self.drops = abs(score) + leng
        self.x0, self.y0 = random.randint(-100,500), 150 - score
        self.w, self.h = leng*2, 20
        self.edge = 15
        self.shape1 = [self.x0, self.y0, self.x0+(self.edge*2), self.y0+self.h]
        self.shape2 = [self.x0+self.edge, self.y0, self.x0+self.w-self.edge, self.y0+self.h+0.4]
        self.shape3 = [self.x0+self.w-(self.edge*2), self.y0, self.x0+self.w, self.y0+self.h]
        self.shape = [self.shape1,self.shape2,self.shape3]
        
        # control colors in hls !!
        self.h = random.randint(0,100)*0.01
        self.l = random.randint(60,90)*0.01
        self.s = random.randint(20,40)*0.01
        rawcolor = colorsys.hls_to_rgb(self.h,self.l,self.s)
        color = []
        for c in rawcolor:
            color.append(int(c*255))
        self.color = '#%02X%02X%02X' % tuple(color)

class Pour:
    def __init__(self):
        pass

    def ing(self, sky, x, y, w, h, color):
        self.x, self.y = x, y
        self.w, self.h = w, h
        self.color = color
        drop = sky.create_rectangle(self.x, self.y, self.x + self.w, self.y + self.h,
                                    fill=self.color, outline="", tags="drop")


        
