package com.example.week14_myapp;

import android.content.Context;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class TXTfile {
    private static final String FILE_NAME = null;

    Context context = null;

    public TXTfile(Context txt_context) {
        context = txt_context;
    }

    public void save(String TXT, String FILE_NAME) {
        if ( TXT == null || TXT.equals("") ) {
            return;
        }

        FILE_NAME = FILE_NAME + ".txt";
        FileOutputStream FOTXT = null;

        try {
            FOTXT = context.openFileOutput(FILE_NAME, Context.MODE_PRIVATE);
            FOTXT.write(TXT.getBytes());
            FOTXT.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String load(String FILE_NAME) {
        FILE_NAME = FILE_NAME + ".txt";

        try {
            FileInputStream FITXT = context.openFileInput(FILE_NAME);
            byte[] TXT = new byte[FITXT.available()];
            while ( FITXT.read(TXT) != -1 ) {}
            return new String(TXT);
        } catch (IOException e) {}

        return "";
    }

    public void delete(String FILE_NAME) {
        FILE_NAME = FILE_NAME + ".txt";
        context.deleteFile(FILE_NAME);
    }

}
